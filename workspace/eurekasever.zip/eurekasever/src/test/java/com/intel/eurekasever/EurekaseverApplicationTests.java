package com.intel.eurekasever;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaseverApplicationTests {

	@Test
	void contextLoads() {
	}

}
