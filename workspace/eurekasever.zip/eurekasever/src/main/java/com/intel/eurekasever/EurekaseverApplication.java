package com.intel.eurekasever;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaseverApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaseverApplication.class, args);
	}

}
